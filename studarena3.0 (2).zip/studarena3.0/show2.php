<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<tr>
		<td>r_id</td>
		<td>title</td>
		<td>category</td>
		<td>description</td>
		<td>image</td>
		<td>price</td>
	</tr>
	<br><br>
	
<?php 

include'includes/dbcon.php';

$id=$_GET['adid'];

 $q="SELECT * FROM postad where category='$id' ";
 $result=mysqli_query($con,$q);
 while ($row=mysqli_fetch_array($result)) {
	

 	$r_id=$row['0'];
 	$title=$row['1'];
 	$cat_id=$row['2'];
 	$category=$row['3'];
 	$description=$row['4'];
 	$image=$row['5'];
 	$price=$row['6'];
?>
<tr align="center">
	<td><?php echo $r_id  ?></td>
	<td><?php echo $cat_id  ?></td>
	<td><?php echo $title  ?></td>
	<td><?php echo $category  ?></td>
	<td><?php echo $description  ?></td>
	<td><?php echo $image  ?></td>
	<td><?php echo $price  ?></td>


</tr>
<?php } ?>

</body>
</html>