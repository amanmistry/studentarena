


<?php 

include'includes/dbcon.php';
//$cat_id=$_SESSION['cat_id'];

if(isset($_GET['adid']))
{
	
	$val=$_GET['adid'];
	$query= "SELECT * FROM postad where r_id = $val";
	if( $query_run = mysqli_query($con,$query) )
	{
		$result = $con->query($query);	
		
		if ($result->num_rows > 0) 
		{
				while($row = $result->fetch_assoc())
				{
					
					?>
                                        <div class="back">
                                        <br><br><br>
					<div class="container" > 
					<div class="row"> 
					<div class="col-sm-6 col-md-6 col-md-offset-3"> 
					<div class="panel panel-primary">
					<div class="panel panel-body">

				<center><div class="col-xs-12" style="font-family:'Lobster' ,cursive;color:green;background-color:light-blue;"><h1><?php echo $row['title'];?></h1></div></center>
					<div class="col-xs-12" style="font-family:'Lobster',cursive;color:black"><h3>
					<?php
					echo "Price : rs." . $row["category"]."<br>";		
					?></h3></div>
					<div class="col-xs-12" style="font-family:'Lobster',cursive;color:black"><h3>
					<?php
					echo  "Negotiable: ".$row["description"]."<br>";		
					?></h3></div>
					<div class="col-xs-12" style="font-family:'Lobster',cursive;color:black"><h3>
					<?php
					echo "Owner : ".$row["image"]."<br>";
					?></h3></div>
					<div class="col-xs-12" style="font-family:'Lobster',cursive;color:black"><h3>
					<?php
					echo "Mail ID : " . $row["price"]."<br>" ;
					?></h3></div>
					<?php

					
					
					//trim ($email);
					?>
					<div class="col-xs-12" style="font-family:'Lobster',cursive;color:black"><h3>
					<?php
					echo "Contact No : " . $row["year"]."<br>";
					?></h3></div>
					<div class="col-xs-12" style="font-family:'Lobster',cursive;color:black"><h3>
					<?php
					echo "Ad details :<br> ". $row["field"]."<br><br>";
					?></h3></div>
					<div class="col-xs-12" style="font-family:'Lobster' ,cursive;color:green;background-color:light-blue;"><h1><?php echo $row['weblink'];?></h1></div>
					<?php
					if(loggedin())
						$id=$_SESSION[' r_id '];
					else
						$id="0";
					if( $row["aduid"] == $id)
					{
						?>  <a href="editad.php?adid=<?php echo $row["adid"]; ?>" class="btn btn-info btn-lg">
								<span class="glyphicon glyphicon-edit"></span> Edit Ad
						</a><?php
					}
					else
					{
						
						?>  <a href="contact.php?eid=<?php echo $row["email"];?>" class="btn btn-info btn-lg">
								<span class="glyphicon glyphicon-envelope"></span> Contact <?php echo $row['owner'];?></a>
						</div>
						</div>
						</div>
						</div>
						</div><?php
					}
				
				}
		}
		
		
	}
	else
		echo "error";
}



 ?>
