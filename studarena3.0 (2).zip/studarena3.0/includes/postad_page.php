<?php
require_once("../includes/dbcon.php");


if(isset($_POST['submit']))
{
//$cat_id=$_POST['cat_id'];
$title=$_POST['title'];
$category=$_POST['category'];
//$books=$_POST['books'];
//$Instruments=$_POST['Instruments'];
//$Accommodation=$_POST['Accommodation'];
//$Tiffin=$_POST['Tiffin'];
$accommodation=$_POST['accommodation'];
//$hostel=$_POST['hostel'];
//$pg=$_POST['pg'];
$year=$_POST['year'];
//$first_Year=$_POST['first_Year'];
//$second_year=$_POST['second_year'];
//$third_Year=$_POST['third_Year'];
$field=$_POST['field'];
//$Mechanical=$_POST['Mechanical'];
//$Electrical=$_POST['Electrical'];
//$Civil=$_POST['Civil'];
//$PCT=$_POST['PCT'];
//$IT=$_POST['IT'];
//$CE=$_POST['CE'];
//$EC=$_POST['EC'];
$description=$_POST['description'];
$price=$_POST['price'];
$weblink=$_POST['weblink'];
$image=$_FILES['image'];
$size_image=$_FILES['image']['size'];
$error_image=$_FILES['image']['error'];
$image_name=$_FILES['image']['name'];
$type_image=$_FILES['image']['type'];
$temp_image=$_FILES['image']['tmp_name'];
$username=$_POST['username'];
$contactno=$_POST['contactno'];
$area=$_POST['area'];

// if(isset($_FILES['file_array'])){
//     $image=$_FILES['image'];
//     $name_array = $_FILES['file_array']['name'];
//     $tmp_name_array = $_FILES['file_array']['tmp_name'];
//     $type_array = $_FILES['file_array']['type'];
//     $size_array = $_FILES['file_array']['size'];
//     $error_array = $_FILES['file_array']['error'];
//     for($i = 0; $i < count($temp_image); $i++){
        // if(move_uploaded_file($temp_image[$i], "../uploadphotos/".$image_name[$i])){
        //     echo $image_name[$i]." upload is complete<br>";
if (move_uploaded_file($temp_image,'../uploadphotos/'.$image_name)) {
	
	
 							

            $query_insert=mysqli_query($con,"INSERT INTO postad #('id', 'title', 'category','accommodation', 'year', 'field', 'description','price', 'weblink', 'image', 'username', 'contactno', 'area') 
 						VALUES ('', '$title', '$category', '$description', '$image', '$price', '$year', '$field', '$weblink', '$accommodation','$username', '$contactno', '$area')");

            header('location:../index.php?msg=Uploding SuccessFull');
            //$_SESSION['category']=$row['category'];


        } else {
            echo "move_uploaded_file function failed for ".$image_name."<br>";
        }
    
//}


// if($type_image=="image/jpg" || $type_image=="image/jpeg" || $type_image=="image/bmp" || $type_image=="image/png")
// 	{
// 		if(move_uploaded_file($temp_image,"../uploadphotos/" .$image_name))
// 					{
// 						$query_insert="INSERT INTO postad #('id', 'title', 'category','accommodation', 'year', 'Field', 'Description','Price', 'weblink', 'Image', 'username', 'contactno', 'Area') 
// 						VALUES ('', '$title', '$category', '$description', '$image', '$price', '$year', '$field', '$weblink', '$accommodation','$username', '$contactno', '$area')";

// 						$insertiontodatabase=mysqli_query($con,$query_insert);
// 						if($insertiontodatabase)
// 						{
// 							header('location:../index.php?msg=Uploding SuccessFull');
// 							exit;
// 						}
// 						else
// 						{
// 							header('location:../index.php?msg=Uploading Error try again');	
// 						}
// 					}
// 					else
// 					{
// 						header('location: ../postad1.php?msg=Uploading Failed.');
// 						exit;
// 					}
// 	}
// 	else
// 	{
// 		header('location: ../postad1.php?msg=Sorry Invalid Type Image!');
// 		exit;
// 	}
}
