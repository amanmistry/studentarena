<?php

/*
if (isset($_POST['submit'])) {

	include_once 'dbcon.php';       

	$username = mysqli_real_escape_string($con, $_POST['username']);
	$email= mysqli_real_escape_string($con, $_POST['email']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$contactno = mysqli_real_escape_string($con, $_POST['contactno']);
	/*$username = mysqli_real_escape_string($con, $_POST['username']);*/

	//error handlers
	//check for empty fields

	/*if (empty($username) || empty($email) || empty($password) || empty($contactno)) {
		header("location: ../signup.php?signup=empty");
		exit();

	} else{
		//check if input characters are valid
		if (!preg_match("/^[a-zA-Z]*$/",$username)) {
			header("location: ../signup.php?signup=invalidusername");
			exit();

		} else{
			//check if input email is valid 
			if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
				header("location: ../signup.php?signup=invalidEMAIL");
				exit();
			} else{
				$sql = "SELECT * FROM register WHERE email='$email'"; 
				$result = mysqli_query($con,$sql);
				$resultcheck = mysqli_num_row($result);

				if ($resultcheck > 0) {
					header("location: ../signup.php?signup=usertaken");
					exit();				
				} else{
				 //hashing the password & number
					$hashedpassword= password_hash($password,password_default);
					$hashednum = contact_hash($contactno,num_default);

				//insert the user into the database 
					$sql =mysqli_query($con,"INSERT INTO register (r_id,username,email,password,contactno) VALUES ('','$username','$email','$hashedpwd','$hashednum')");				
					$result = mysqli_query($sql);
					header("location: ../signup.php?signup=singup_success");
					exit();	
				}
			}

		} 
	} 

}	else {

		header("location: ../signup.php");
		exit();

	}
*/









	 



if (isset($_POST['submit'])) { 

	include_once 'dbcon.php';

	$username=mysqli_real_escape_string($con,$_POST['username']);
	//$last=mysqli_real_escape_string($conn,$_POST['last']);
	$email=mysqli_real_escape_string($con,$_POST['email']);
	$password=mysqli_real_escape_string($con,$_POST['password']);
	$contactno=mysqli_real_escape_string($con,$_POST['contactno']);

//error handlers
//check for empty fields
if (empty($username)  || empty($email) || empty($contactno) || empty($password)) {

header("location: ../register.html?signup=empty");
	exit();
}
else{
	//check if inpur characters are valid 
	if (!preg_match("/^[a-zA-Z]*$/",$username)) {
		header("location: ../register.html?signup=invalid");
	exit();
	 	  
	 } 
	 else{
	 	/*check if email valid*/
	 	if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
	 		header("location: ../register.html?signup=email");
	 		exit();
	 	}else{
	 		$sql="SELECT * FROM register WHERE username='$username'";
	 		$result=mysqli_query($con,$sql);
	 		$resultCheck=mysqli_num_rows($result);
	 		if ($resultCheck>0) {
	 			header("location: ../register.html?signup=usertaken");
	 		exit();
	 		}else
	 		{
	 			//hashing the password
	 			$hashedPwd=password_hash($password,PASSWORD_DEFAULT);
	 			//insert the user into the database
	 			$sql="INSERT INTO register#(user_first,user_last,user_email,user_uid,user_pwd) 
	 			VALUES('','$username','$email','$hashedPwd','$contactno');";
	 			$result=mysqli_query($con,$sql);
	 			header("location: ../login.html?signup=success");
	 		exit();
	 		}
	 	}
	 }

}
}
else{
	header("location: ../register.html");
	exit();
}

?>