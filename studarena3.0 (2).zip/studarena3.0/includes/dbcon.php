<?php

$host="localhost";
$name="root";
$pass="";
$db="students arena";


$con=mysqli_connect($host,$name,$pass,$db);
if(mysqli_connect_errno()){
	
	echo"failed to connect".mysqli_connect_error();
}


?>