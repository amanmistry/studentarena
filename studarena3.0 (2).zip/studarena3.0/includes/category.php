<?php
	if (isset($_GET['subj'])) {
		$sel_subj = $_GET['subj'];
		$sel_page = "";
	} elseif (isset($_GET['page'])) {
		$sel_subj = "";
		$sel_page = $_GET['page'];
	} else {
		$sel_subj = "";
		$sel_page = "";
	}
?>

<?php
		$subject_set = get_all_subjects();
		while ($subject = mysql_fetch_array($subject_set)) {
			echo "<li";
			if ($subject["id"] == $sel_subj) { echo " class=\"selected\""; }
			echo "><a href=\"#?subj=" . urlencode($subject["id"]) . 
				"\">{$subject["title"]}</a></li>";
			$page_set = get_pages_for_subject($subject["id"]);
			echo "<ul class=\"ullist\">";
			while ($page = mysql_fetch_array($page_set)) {
				echo "<li";
				if ($page["id"] == $sel_page) { echo " class=\"selected\""; }
				echo "><a href=\"content.php?page=" . urlencode($page["id"]) .
					"\">{$page["sub_title"]}</a></li>";
			}
			echo "</ul>";
		}

		?>