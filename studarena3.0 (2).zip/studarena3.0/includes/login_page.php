 <?php
 session_start();

/* if (isset($_POST['submit'])) {
 	
 	include 'dbcon.php';

  $username = mysqli_real_escape_string($con, $_POST['username']);
  $pwd = mysqli_real_escape_string($con, $_POST['pwd']);


  if (empty($username) || empty($pwd)) {
		header("location: ../index.php?login=empty");
	   exit();

}      else {
	  $sql ="SELECT * FROM register WHERE username='$username' or email ='$username'"; 
			$result = mysqli_query($con,$sql);
			$resultcheck = mysqli_num_row($result);
    if ($resultcheck < 1) {
			header("location: ../index.php?login=error");
            exit();
			
}	       else {
	 if($row = mysqli_fetch_assoc($result)) {
	 	// de-hashing password
     $hashedpwdcheck == password_verify($pwd,$row['register_pwd']);
     	if ($hashedpwdcheck == false) {
        header("location: ../index.php?login=error");
     	exit();
     	} elseif($hashedpwdcheck == true) {
     	
        //login the user here
     	$_session['username']  = $row ['username'];
     	$_session['email']  = $row ['email'];
     	$_session['password']  = $row ['password'];
        $_session['contactno']  = $row ['contactno'];
        header("location: ../index.php?login=success");
     	exit();
        }     	
    }

}
    }
}

else{
header("location: ../index.php?login=error");
        exit();
}
?>
*/



if (isset($_POST['submit'])) {

    include 'dbcon.php';

    $username=mysqli_real_escape_string($con,$_POST['username']);
    $password=mysqli_real_escape_string($con,$_POST['password']);
   // $email=mysqli_real_escape_string($con,$_POST['email']);

//error handlers
    //check if inputs are empty
    if (empty($username) || empty($password)) {
        header("location: ../login.html?login=empty field");
        echo "fill all field";
        exit();  
    } else {
        $sql="SELECT * FROM register WHERE username='$username' OR email='$username'";
        $result=mysqli_query($con,$sql);
        $resultCheck=mysqli_num_rows($result);
        if ($resultCheck<1) {
            header("location: ../login.html?login=wrong username");
            echo "wrong input";
            exit();
        
    }else{
        if ($row=mysqli_fetch_assoc($result)) {
    //      echo $row['user_uid'];
            //de-hashing the password
            $hashedPwdCheck=password_verify($password,$row['password']);
            if ($hashedPwdCheck==false) {
                header("location: ../login.html?login=wrong password");
                echo "wrong password";
                 exit();

            } elseif ($hashedPwdCheck==true) {
            //log in the user here
                $_SESSION['username']=$row['username'];
                $_SESSION['password']=$row['password'];
                $_SESSION['email']=$row['email'];
                $_SESSION['contactno']=$row['contactno'];
                $_SESSION['r_id']=$row['r_id'];
                //$_SESSION['u_uid']=$row['user_uid'];
                header("location: ../postad.html?login=success");
        exit();
            }
        }
    }

}

 }
//else{
// header("location: ../index.php?login=error enter email");
//         exit();

// }
 ?>